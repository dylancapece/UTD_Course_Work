READ ME (cps.cpp) Program 2: 

a. Team Members: Dylan Capece, Mark Luka (Did it individually this time using code from Program1 that we did together).

b. Procedure to compile and run: 

	1. Create a test.txt file and enter an array of numbers of size m that can be divided evenly into 2 into it; separate each number with a space. 
	2. compile using g++ -o cps cps.cpp
	3. run using ./cps 8 test.txt output.txt 2  
	4. the number 8 represents the array length and 2 means how many threads also represented by n and m in the code. 
	4. output.txt should contain the array being added with each number. The terminal should output the thread id's. 
	

Warning: I have been getting a weird mac specific problem using boost. It is causing compilation errors. 



