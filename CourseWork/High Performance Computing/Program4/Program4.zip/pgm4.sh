#!/bin/bash
#SBATCH -p COMETS
#SBATCH -N 1
#SBATCH -t 02:00:00
#SBATCH --exclusive
#SBATCH --ntasks-per-node=1

/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
/home/dsc160330/pgm4.exe
